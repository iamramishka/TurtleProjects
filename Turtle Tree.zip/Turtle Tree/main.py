import turtle

# Set up the window and turtle
window = turtle.Screen()
window.bgcolor("white")
fractal_turtle = turtle.Turtle()
fractal_turtle.speed(0)  # fastest speed

# Function to draw a fractal tree
def draw_fractal_tree(t, branch_length, angle, min_length=10):
    if branch_length > min_length:
        t.forward(branch_length)
        t.right(angle)
        draw_fractal_tree(t, branch_length - 15, angle, min_length)
        t.left(angle * 2)
        draw_fractal_tree(t, branch_length - 15, angle, min_length)
        t.right(angle)
        t.backward(branch_length)

# Initial setup
fractal_turtle.left(90)  # point the turtle upwards
fractal_turtle.penup()
fractal_turtle.goto(0, -200)  # start drawing from the bottom of the screen
fractal_turtle.pendown()

# Draw the tree
draw_fractal_tree(fractal_turtle, 100, 20)  # 100 is the initial branch length, 20 is the angle

# Finish up
fractal_turtle.hideturtle()
window.mainloop()
