import turtle
import time

# Set up the screen
screen = turtle.Screen()
screen.bgcolor("black")  # Dark background

# Create a turtle
spirograph = turtle.Turtle()
spirograph.speed(0)  # Set the speed to the maximum

# List of bright colors to use
colors = ["red", "cyan", "lime", "yellow", "magenta", "white"]

# Function to draw a circle spirograph
def draw_circle_spirograph(radius, gap_angle):
    for angle in range(0, 360, gap_angle):
        spirograph.color(colors[angle % len(colors)])  # Change color
        spirograph.setheading(angle)
        spirograph.circle(radius)
        spirograph.penup()
        spirograph.goto(0, 0)
        spirograph.pendown()

# Function to draw a square spirograph
def draw_square_spirograph(side_length, gap_angle):
    for angle in range(0, 360, gap_angle):
        spirograph.color(colors[angle % len(colors)])  # Change color
        spirograph.setheading(angle)
        for _ in range(4):
            spirograph.forward(side_length)
            spirograph.right(90)
        spirograph.penup()
        spirograph.goto(0, 0)
        spirograph.pendown()

# Draw the circle spirograph 3 times with different settings
for i in range(3):
    radius = 100 + i * 10  # Increment radius for each iteration
    gap_angle = 10 + i  # Change gap angle for each iteration
    draw_circle_spirograph(radius, gap_angle)

# Wait for 5 seconds
time.sleep(5)

# Clear the screen
spirograph.clear()

# Draw the square spirograph 3 times with different settings
for i in range(3):
    side_length = 100 + i * 20  # Increment side length for each iteration
    gap_angle = 10 + i * 5  # Change gap angle for each iteration
    draw_square_spirograph(side_length, gap_angle)

# Hide the turtle and display the result
spirograph.hideturtle()
turtle.done()
