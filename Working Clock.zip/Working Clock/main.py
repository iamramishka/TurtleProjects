import turtle
import time

# Set up the screen
screen = turtle.Screen()
screen.bgcolor("black")
screen.setup(width=600, height=600)
screen.title("Turtle Clock")
screen.tracer(0)

# Create the turtle for drawing the clock face
clock = turtle.Turtle()
clock.hideturtle()
clock.speed(0)
clock.pensize(3)

# Function to draw the clock face
def draw_clock():
    clock.penup()
    clock.goto(0, -290)
    clock.pendown()
    clock.color("white")
    clock.circle(290)
    
    # Draw hour markers
    clock.penup()
    clock.goto(0, 0)
    clock.setheading(90)

    for _ in range(12):
        clock.forward(250)
        clock.pendown()
        clock.forward(40)
        clock.penup()
        clock.goto(0, 0)
        clock.right(30)

# Create turtles for the hands
second_hand = turtle.Turtle()
second_hand.shape("arrow")
second_hand.color("red")
second_hand.speed(0)
second_hand.shapesize(stretch_wid=0.5, stretch_len=18)

minute_hand = turtle.Turtle()
minute_hand.shape("arrow")
minute_hand.color("white")
minute_hand.speed(0)
minute_hand.shapesize(stretch_wid=1, stretch_len=15)

hour_hand = turtle.Turtle()
hour_hand.shape("arrow")
hour_hand.color("white")
hour_hand.speed(0)
hour_hand.shapesize(stretch_wid=1, stretch_len=10)

# Function to update the hands
def update_hands():
    current_time = time.localtime()
    seconds = current_time.tm_sec
    minutes = current_time.tm_min
    hours = current_time.tm_hour

    # Calculate the angles for each hand
    sec_angle = 6 * seconds
    min_angle = 6 * minutes + 0.1 * seconds
    hour_angle = 30 * (hours % 12) + 0.5 * minutes

    # Update hand positions
    second_hand.setheading(90 - sec_angle)
    minute_hand.setheading(90 - min_angle)
    hour_hand.setheading(90 - hour_angle)

    screen.update()
    screen.ontimer(update_hands, 1000)

# Draw the clock face
draw_clock()

# Start updating the hands
update_hands()

# Keep the window open
turtle.done()
